"""Oilfield Simulator 2.0 - educational integrated field model."""
