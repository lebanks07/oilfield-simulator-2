from dataclasses import dataclass
from math import exp

@dataclass
class ProductionWell:
    name: str
    initial_oil_rate_stb_day: float = 500.0
    annual_decline: float = 0.20
    water_cut: float = 0.20
    gor_scf_stb: float = 800.0
    start_day: int = 0

    def __post_init__(self):
        if self.initial_oil_rate_stb_day < 0 or self.annual_decline < 0:
            raise ValueError("Initial rate and decline must be nonnegative.")
        if not 0 <= self.water_cut < 1 or self.gor_scf_stb < 0:
            raise ValueError("Water cut must be [0,1); GOR must be nonnegative.")

    def daily(self, day):
        elapsed = max(0, day-self.start_day)
        qo = self.initial_oil_rate_stb_day*exp(-self.annual_decline*elapsed/365.25)
        qw = qo*self.water_cut/max(1-self.water_cut, 1e-12)
        qg = qo*self.gor_scf_stb
        return {"day": day, "well": self.name, "oil_stb_day": qo,
                "water_bbl_day": qw, "gas_scf_day": qg}

    def forecast(self, days):
        return [self.daily(d) for d in range(days)]

def field_forecast(wells, days):
    if days < 1:
        raise ValueError("Forecast days must be at least 1.")
    rows = []
    for day in range(days):
        daily = [w.daily(day) for w in wells]
        rows.append({
            "day": day,
            "oil_stb_day": sum(x["oil_stb_day"] for x in daily),
            "water_bbl_day": sum(x["water_bbl_day"] for x in daily),
            "gas_scf_day": sum(x["gas_scf_day"] for x in daily),
            "cumulative_oil_stb": sum(sum(w.daily(d)["oil_stb_day"] for w in wells)
                                      for d in range(day+1))
        })
    return rows
