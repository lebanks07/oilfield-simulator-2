from dataclasses import dataclass

@dataclass
class EconomicAssumptions:
    oil_price_usd_bbl: float = 70.0
    operating_cost_usd_bbl: float = 12.0
    annual_fixed_opex_usd: float = 1_000_000.0
    initial_capex_usd: float = 15_000_000.0
    discount_rate: float = 0.10
    tax_rate: float = 0.0

    def evaluate(self, forecast):
        if not 0 <= self.tax_rate < 1 or self.discount_rate < 0:
            raise ValueError("Tax rate must be [0,1); discount rate must be nonnegative.")
        if min(self.oil_price_usd_bbl, self.operating_cost_usd_bbl,
               self.annual_fixed_opex_usd, self.initial_capex_usd) < 0:
            raise ValueError("Economic inputs cannot be negative.")
        annual = {}
        for row in forecast:
            year = row["day"] // 365
            annual.setdefault(year, 0.0)
            annual[year] += row["oil_stb_day"]
        cashflows = [-self.initial_capex_usd]
        for year in sorted(annual):
            revenue = annual[year]*self.oil_price_usd_bbl
            variable = annual[year]*self.operating_cost_usd_bbl
            fixed = self.annual_fixed_opex_usd
            pretax = revenue-variable-fixed
            tax = max(0.0, pretax)*self.tax_rate
            cashflows.append(pretax-tax)
        npv = sum(cf/((1+self.discount_rate)**i) for i, cf in enumerate(cashflows))
        cumulative = 0.0
        payback_year = None
        for i, cf in enumerate(cashflows):
            cumulative += cf
            if cumulative >= 0 and payback_year is None:
                payback_year = i
        return {"cashflows_usd": cashflows, "npv_usd": npv,
                "payback_year": payback_year,
                "undiscounted_net_cashflow_usd": sum(cashflows)}
