from dataclasses import dataclass
import numpy as np

@dataclass
class ReservoirGrid:
    nx: int = 12
    ny: int = 12
    nz: int = 3
    cell_dx_ft: float = 500.0
    cell_dy_ft: float = 500.0
    cell_dz_ft: float = 20.0
    porosity_mean: float = 0.20
    permeability_mean_md: float = 100.0
    initial_pressure_psi: float = 3500.0
    water_saturation: float = 0.25
    oil_fvf: float = 1.20
    seed: int = 7

    def __post_init__(self):
        if min(self.nx, self.ny, self.nz) < 1:
            raise ValueError("Grid dimensions must be positive.")
        if min(self.cell_dx_ft, self.cell_dy_ft, self.cell_dz_ft) <= 0:
            raise ValueError("Cell dimensions must be positive.")
        if not 0 < self.porosity_mean < 1:
            raise ValueError("Mean porosity must be between 0 and 1.")
        if self.permeability_mean_md <= 0 or self.oil_fvf <= 0:
            raise ValueError("Permeability and oil FVF must be positive.")
        if not 0 <= self.water_saturation < 1:
            raise ValueError("Water saturation must be in [0, 1).")
        rng = np.random.default_rng(self.seed)
        self.porosity = np.clip(rng.normal(self.porosity_mean, 0.025,
                              (self.nz, self.ny, self.nx)), 0.05, 0.35)
        # Lognormal heterogeneity with approximately the requested arithmetic mean.
        sigma = 0.55
        mu = np.log(self.permeability_mean_md) - 0.5 * sigma**2
        self.permeability_md = rng.lognormal(mu, sigma,
                                  (self.nz, self.ny, self.nx))
        self.pressure_psi = np.full((self.nz, self.ny, self.nx),
                                    self.initial_pressure_psi, dtype=float)

    @property
    def bulk_volume_ft3(self):
        return self.nx*self.cell_dx_ft * self.ny*self.cell_dy_ft * self.nz*self.cell_dz_ft

    def ooip_stb(self):
        """Cell-by-cell volumetric OOIP estimate."""
        pore_volume_ft3 = self.porosity * self.cell_dx_ft*self.cell_dy_ft*self.cell_dz_ft
        pore_volume_bbl = pore_volume_ft3 / 5.615
        return float(np.sum(pore_volume_bbl * (1-self.water_saturation) / self.oil_fvf))

    def apply_pressure_depletion(self, cumulative_oil_stb, effective_compressibility=1.0e-5):
        """Illustrative uniform depletion proxy, not a numerical flow solver."""
        if cumulative_oil_stb < 0 or effective_compressibility <= 0:
            raise ValueError("Cumulative oil must be >= 0 and compressibility > 0.")
        pore_volume_bbl = self.bulk_volume_ft3 * self.porosity_mean / 5.615
        drop = cumulative_oil_stb / max(pore_volume_bbl*effective_compressibility, 1.0)
        self.pressure_psi[:] = max(14.7, self.initial_pressure_psi-drop)
        return self.pressure_psi.copy()

    def summary(self):
        return {
            "grid_cells": int(self.nx*self.ny*self.nz),
            "mean_porosity": float(self.porosity.mean()),
            "mean_permeability_md": float(self.permeability_md.mean()),
            "ooip_stb": self.ooip_stb(),
            "mean_pressure_psi": float(self.pressure_psi.mean())
        }
