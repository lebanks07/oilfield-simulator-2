from dataclasses import dataclass
import math

@dataclass
class WellTrajectory:
    measured_depth_ft: float = 10000.0
    inclination_deg: float = 0.0
    azimuth_deg: float = 0.0
    dogleg_severity_deg_per_100ft: float = 0.0

    def calculate(self):
        if self.measured_depth_ft <= 0:
            raise ValueError("Measured depth must be positive.")
        if not 0 <= self.inclination_deg <= 90:
            raise ValueError("Inclination must be between 0 and 90 degrees.")
        inc = math.radians(self.inclination_deg)
        azi = math.radians(self.azimuth_deg)
        tvd = self.measured_depth_ft * math.cos(inc)
        north = self.measured_depth_ft * math.sin(inc) * math.cos(azi)
        east = self.measured_depth_ft * math.sin(inc) * math.sin(azi)
        return {"md_ft": self.measured_depth_ft, "tvd_ft": tvd,
                "north_offset_ft": north, "east_offset_ft": east,
                "dogleg_severity_deg_per_100ft": self.dogleg_severity_deg_per_100ft}

@dataclass
class DrillingHydraulics:
    mud_weight_ppg: float = 10.0
    depth_ft: float = 10000.0
    flow_rate_gpm: float = 500.0
    bit_pressure_drop_psi: float = 500.0
    annular_friction_loss_psi: float = 250.0
    formation_pressure_psi: float = 5200.0
    fracture_pressure_psi: float = 6800.0

    def calculate(self):
        if min(self.mud_weight_ppg, self.depth_ft, self.flow_rate_gpm) <= 0:
            raise ValueError("Mud weight, depth, and flow rate must be positive.")
        hydro = 0.052*self.mud_weight_ppg*self.depth_ft
        ecd = self.mud_weight_ppg + self.annular_friction_loss_psi/(0.052*self.depth_ft)
        bhp_static = hydro
        bhp_circulating = hydro+self.annular_friction_loss_psi
        return {
            "hydrostatic_pressure_psi": hydro,
            "ecd_ppg": ecd,
            "circulating_bhp_psi": bhp_circulating,
            "bit_pressure_drop_psi": self.bit_pressure_drop_psi,
            "formation_pressure_psi": self.formation_pressure_psi,
            "fracture_pressure_psi": self.fracture_pressure_psi,
            "simplified_pressure_window_pass": self.formation_pressure_psi <= bhp_circulating <= self.fracture_pressure_psi
        }
