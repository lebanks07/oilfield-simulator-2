import argparse
import json
from pathlib import Path
from oilfield.reservoir import ReservoirGrid
from oilfield.drilling import WellTrajectory, DrillingHydraulics
from oilfield.production import ProductionWell, field_forecast
from oilfield.economics import EconomicAssumptions

def build_demo(days=1095):
    reservoir = ReservoirGrid()
    wells = [
        ProductionWell("WELL-01", 500, 0.20, 0.20, 800, 0),
        ProductionWell("WELL-02", 350, 0.16, 0.25, 950, 90),
        ProductionWell("WELL-03", 250, 0.22, 0.15, 700, 180),
    ]
    forecast = field_forecast(wells, days)
    cumulative = forecast[-1]["cumulative_oil_stb"]
    reservoir.apply_pressure_depletion(cumulative)
    economics = EconomicAssumptions().evaluate(forecast)
    return {
        "reservoir": reservoir.summary(),
        "drilling": {
            "trajectory": WellTrajectory(12000, 60, 45, 2.0).calculate(),
            "hydraulics": DrillingHydraulics().calculate()
        },
        "field": {
            "well_count": len(wells),
            "forecast_days": days,
            "initial_oil_rate_stb_day": forecast[0]["oil_stb_day"],
            "final_oil_rate_stb_day": forecast[-1]["oil_stb_day"],
            "cumulative_oil_stb": cumulative,
            "final_water_rate_bbl_day": forecast[-1]["water_bbl_day"],
            "final_gas_rate_scf_day": forecast[-1]["gas_scf_day"]
        },
        "economics": economics,
        "forecast": forecast
    }

def main():
    parser = argparse.ArgumentParser(description="Oilfield Simulator 2.0")
    parser.add_argument("--days", type=int, default=1095)
    parser.add_argument("--output", default="simulation_results.json")
    args = parser.parse_args()
    if args.days < 1:
        parser.error("--days must be >= 1")
    result = build_demo(args.days)
    Path(args.output).write_text(json.dumps(result, indent=2), encoding="utf-8")
    print("OILFIELD SIMULATOR 2.0")
    print("="*52)
    print(f"Reservoir grid: {result['reservoir']['grid_cells']} cells")
    print(f"Estimated OOIP: {result['reservoir']['ooip_stb']:,.0f} STB")
    print(f"Field wells: {result['field']['well_count']}")
    print(f"Initial field oil rate: {result['field']['initial_oil_rate_stb_day']:,.1f} STB/day")
    print(f"Final field oil rate: {result['field']['final_oil_rate_stb_day']:,.1f} STB/day")
    print(f"Cumulative oil: {result['field']['cumulative_oil_stb']:,.0f} STB")
    print(f"Illustrative NPV: ${result['economics']['npv_usd']:,.0f}")
    print(f"Results saved to: {args.output}")

if __name__ == "__main__":
    main()
