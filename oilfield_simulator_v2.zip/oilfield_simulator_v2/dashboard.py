"""Optional Streamlit dashboard. Install requirements-dashboard.txt to run."""
import streamlit as st
import pandas as pd
import plotly.express as px
from main import build_demo

st.set_page_config(page_title="Oilfield Simulator 2.0", layout="wide")
st.title("Oilfield Simulator 2.0")
st.caption("Educational integrated reservoir, drilling, production and economics model")
days = st.sidebar.slider("Forecast duration (days)", 365, 3650, 1095, 365)
result = build_demo(days)
field = result["field"]
c1, c2, c3, c4 = st.columns(4)
c1.metric("Wells", field["well_count"])
c2.metric("Cumulative oil", f'{field["cumulative_oil_stb"]:,.0f} STB')
c3.metric("Final oil rate", f'{field["final_oil_rate_stb_day"]:,.0f} STB/day')
c4.metric("Illustrative NPV", f'${result["economics"]["npv_usd"]/1e6:,.2f}M')
df = pd.DataFrame(result["forecast"])
st.subheader("Field production forecast")
st.plotly_chart(px.line(df, x="day", y=["oil_stb_day", "water_bbl_day"],
                        labels={"value": "Rate (bbl/day)", "variable": "Stream"}),
                use_container_width=True)
st.subheader("Cumulative oil")
st.plotly_chart(px.line(df, x="day", y="cumulative_oil_stb",
                        labels={"cumulative_oil_stb": "Cumulative oil (STB)"}),
                use_container_width=True)
left, right = st.columns(2)
with left:
    st.subheader("Reservoir")
    st.json(result["reservoir"])
with right:
    st.subheader("Drilling")
    st.json(result["drilling"])
st.subheader("Economics")
st.json({k:v for k,v in result["economics"].items() if k != "cashflows_usd"})
st.dataframe(df.tail(10), use_container_width=True)
