# Oilfield Simulator 2.0

An integrated **educational prototype** combining a heterogeneous 3D reservoir grid,
well trajectory calculations, simplified drilling hydraulics, multi-well production
forecasting, field aggregation, and discounted cash-flow analysis.

## Features

- **Reservoir:** seeded 3D porosity/permeability arrays, volumetric OOIP, and a simple
  uniform pressure-depletion proxy.
- **Drilling:** inclination/azimuth trajectory geometry, TVD and offsets, hydrostatic
  pressure, approximate ECD, and a simplified pressure-window indicator.
- **Production:** multiple wells, exponential decline, water-cut and GOR estimates,
  field rates and cumulative oil.
- **Economics:** annual revenue, variable/fixed operating costs, CAPEX, tax assumption,
  discounted NPV and simple payback indicator.
- **Dashboard:** optional Streamlit charts and controls.

## Install and run

Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python main.py --days 1095
```

The CLI writes `simulation_results.json`.

## Optional interactive dashboard

```bash
pip install -r requirements-dashboard.txt
streamlit run dashboard.py
```

## Model limitations — important

This is **not** a commercial reservoir simulator or a safe basis for field operations.
The 3D grid currently represents heterogeneous static properties; it does not solve
multiphase Darcy flow or pressure/saturation transport. Pressure depletion is a
uniform illustrative proxy. The drilling hydraulics omit detailed rheology, pipe and
annular geometry, friction correlations, cuttings transport, transient ECD, surge/swab,
kick tolerance and well-control physics. Production uses deterministic exponential
decline and fixed water cut/GOR. Economics are simplified and omit royalties,
differentials, abandonment, working capital, financing, fiscal terms and uncertainty.

Do not use outputs to make drilling, completion, production, safety, reserves, or
investment decisions. Real use requires calibrated field data, validated physics,
unit controls, uncertainty analysis, independent verification, and qualified
engineering review.

## Next engineering steps

1. Add unit-aware PVT and fluid-property models.
2. Implement finite-volume multiphase flow and pressure/saturation updates.
3. Add well productivity/injectivity and well-reservoir coupling.
4. Implement validated hydraulics with rheology and pipe geometry.
5. Add history matching, uncertainty ensembles, and automated regression tests.
6. Add data import/export, audit trails, and role-based project management.
